//this panel is the bottom left menu
import javax.swing.*;
import java.awt.*;

class LeftMenu {


}
