public class Tag{
	
	int tagNumber;
	int time;
	int xPosition;
	int slidePosition;
	String value;

	public Tag(int tagNumber, int time){
		this.tagNumber = tagNumber;
		this.time = time;
	}


	public void setXPostion(){
		//find the value from progress bar for the x-coordinate to draw
	}
	

}
